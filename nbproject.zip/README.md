Do you wish to convert your music to a form in which others cannot listen it? 
Do you wish to convert your movies to a form in which others cannot watch them? 
Do you wish to convert your documents to a form in which others cannot read them? 
Do you wish to convert your executable files to a form in which others cannot execute them?

If your answer to any of the above questions is  "YES"  then this software is definitely for you. 

With this software you can perform ENCRYPTION and encrypt your video files, audio files, text files, executable files, pdf, or any other file of your choice. 
This way, without your password, files such as movies,music, pdf, documents, images, etc. won't open. Executable files will no longer be in a state to be executed. 

Would you like to have your encrypted files back in the form they used to be?

Don't worry. It is also other way around. With the password you had used for encryption you can perform DECRYPTION and convert your files back to their original form.
Moreover, the application does NOT store your passwords.  Instead it uses SHA-512 hashing algorithm to verify the password.

Demonstration of the application available at: https://youtu.be/rt5jLN4jJ_U
